### R code for displaying the similarity matrix ###

# Read in the table of clusterings
workdir <- "___XXX___"
x <- read.table(paste(workdir, "___XXX___", sep=""), header=TRUE)
# Abbreviations for display
renames <- matrix(c(
"___XXX___", "___XXX___",
"___XXX___", "___XXX___",
"___XXX___", "___XXX___"),



nrow=___XXX___, ncol=2, byrow=TRUE)
# Minimal cluster names are column names omitting first 4
mincl.names <- colnames(x)[-(1:4)]
# Check for typos, etc
for (i in 1:length(mincl.names)) {
stopifnot(mincl.names[i] == renames[i,1])
}

# Make the similarity matrix
displaynames <- renames[,2]
nmincls <- length(displaynames)
sim <- matrix(0, ncol=nmincls, nrow=nmincls, dimnames=list(displaynames, displaynames))
for (i in 1:nmincls) {
for (j in 1:nmincls) {
coli <- x[,mincl.names[i]]
colj <- x[,mincl.names[j]]
w <- coli == colj
sim[i,j] <- sum(x[w,"fraction"])
}
}
# ensure rounding errors don’t make probabilities sum to more than 1.
sim <- pmin(sim,1)
# change the order of minimal clusters
# This depends on which patterns you want to emphasise
#neworder <- c(36,35,14,13,3,4,8,11,16,15,47,56,41,40,24,25,42,38,21,23,43,44,49,50,26,28,1,2,55,52,33,20,22,19,34,32,6,10,5,12,45,46,54,53,9,7,51,48,30,31,18,17,39,37,27,29)
neworder <- c(___XXX___)
# Currently recognised groups
dividers <- c(0,___XXX___)
plot.rectangle <- function(v1,v2,...)
{
polygon(c(v1[1],v2[1],v2[1],v1[1]), c(v1[2],v1[2],v2[2],v2[2]), ...)
}
# Main plotting routine
plot.simmatrix <- function() {
par(mar= c(0,5,5,0)+.1)
plot(NULL, xlim=c(0,nmincls), ylim=c(nmincls,0), axes=FALSE, ylab="", xlab="")
axis(3, at=(1:nmincls)-.5, displaynames[neworder], tick=FALSE, las=2, line=-1)
axis(2, at=(1:nmincls)-.5, displaynames[neworder], tick=FALSE, las=2, line=-1)
for (i in 1:nmincls) {
for (j in 1:nmincls) {
d <- 1 - sim[neworder[i],neworder[j]]
plot.rectangle(c(i-1,j-1), c(i,j), col=rgb(d,d,d), border="white")
}
}
for (b in dividers) {
lines(x=c(-.5,nmincls), y=c(b,b))
lines(x=c(b,b), y=c(-.5,nmincls))
}
}
# Display as text, on screen, and to PDF file
print(sim[neworder,neworder], digits=2)
plot.simmatrix()
#pdf(file=paste(workdir, "simmatrix_e18_prova_1.pdf", sep=""))
svg(filename = '___XXX___',  width=33, height=33)
plot.simmatrix()
dev.off()
}
