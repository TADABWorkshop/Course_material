

# ECDF plots (Empirical Cumulative Distribution Function (CDF) Plots)
library(ggplot2)



# An ECDF represents the proportion or count of observations falling below each unique value in a dataset. 
# Compared to a histogram or density plot, it has the advantage that each observation is visualized directly, 
# meaning that there are no binning or smoothing parameters that need to be adjusted

# This R tutorial describes how to create an ECDF plot (or Empirical Cumulative Density Function) using R software 
# and ggplot2 package. ECDF reports for any given number the percent of individuals that are below that threshold.
# The function stat_ecdf() can be used.




# Create some data
set.seed(1234)
fentanyl <- data.frame(concentration = rnorm(1000, mean=0.00061, sd=0.05))
head(fentanyl)


# ECDF plots
ggplot(fentanyl, aes(concentration)) + stat_ecdf(geom = "point")
ggplot(fentanyl, aes(concentration)) + stat_ecdf(geom = "step")



# Customized ECDF plots

# Basic ECDF plot
sp <- ggplot(fentanyl, aes(concentration)) + stat_ecdf(geom = "step")+
  labs(title="Empirical Cumulative \n Density Function",
       y = "Probability of analgesia", x="Fentanyl concentration (mg/kg)")+
  theme_classic()
sp

# Add horizontal line at y = 0.5 (ED50)...
sp + geom_hline(yintercept=0.5, linetype="dashed", color = "red")

# Add horizontal line at y = 0.95 (effective dose in 95%)...
sp + geom_hline(yintercept=0.95, linetype="dashed", color = "red")

# Add horizontal line at x = 0.00061..
sp + geom_vline(xintercept=0.00061)

# Change line type and color...
sp + geom_hline(yintercept=0.5, linetype="dashed", color = "red")

# Change line size
sp + geom_hline(yintercept=0.5, linetype="dashed", 
                color = "red", size=2)





# Additional information can be retrived at
# STHDA - Statistical tools for high-throughput data analysis
# http://www.sthda.com/english/wiki/ggplot2-essentials
