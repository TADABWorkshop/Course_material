distance <- function(table,target){
  #table is a 3 column dataframe
  x1 <- target[1]
  y1 <- target[2]
  z1 <- target[3]
  
  d <- double()
  for (i in 1:nrow(table)) {
    x2 <- table[i,1]
    y2 <- table[i,2]
    z2 <- table[i,3]
    d[i] = ((x2 - x1)^2 + (y2 - y1)^2 + (z2 - z1)^2)^(1/2)                         
    d
  }
  {
    return(d)
  }
}
statix <- function(table){
  st_dev <- sd(table)
  mean <- mean(table)
  median <- median(table)
  tab <- cbind(as.data.frame(st_dev),as.data.frame(mean),as.data.frame(median))
  {
    return(tab)
  }
}
opendir <- function(dir = getwd()){
  if (.Platform['OS.type'] == "windows"){
    shell.exec(dir)
  } else {
    system(paste(Sys.getenv("R_BROWSER"), dir))
  }
}

dist0 <- read.csv("C:/Users/david/Documents/ggplot2/Range & Stability & D_index 35 var.csv", row.names = 1)

#setwd("E:/Model_Factory_David/risultati 0.5 minuti/35 variabili/raster/output/corrected_prevalence_res/all results 35 variabili")
#dist0 <- read.csv("Selected_res_35_variabili.csv", row.names = 1)

#-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-#

head(dist0,3)

dist <- dist0[c("SpeciesRangeChange","PercStable","D_index" )]
target <- c(0,100,1)
res <- distance(dist,target)
dist$Dist <- res
dist2 <- cbind(dist0[1:2], dist)
newdata <- dist2[order(dist2$Dist),]


head(newdata)


#-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-#
#SpeciesRangeChange
df <- dist2[c("Method", "SpeciesRangeChange")]
head(df,3)
colnames(df) <-c("Method","Values")
data_matrix <- as.data.frame(matrix(nrow = 0,ncol = 4))

method <- unique(df$Method)

for (d in 1:length(method)) {
  val <- subset(df,Method==method[d])
  statix.val <- statix(val$Values)
  
  res <- data.frame(Method=method[d],
                    st_dev=statix.val$st_dev,
                    mean=statix.val$mean,
                    median=statix.val$median)
  data_matrix <- rbind(data_matrix,res)
}

final.df <- data_matrix[c(1,3)]
final.df_sd <- data_matrix[c(1,2)]
final.df_median <- data_matrix[c(1,4)]

colnames(final.df) <- c("Method", "Range_Size_Variation")
colnames(final.df_sd) <- c("Method", "Range_Size_Variation")
colnames(final.df_median) <- c("Method", "Range_Size_Variation")



#-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-#
#PercStable
df <- dist2[c("Method", "PercStable")]
head(df,3)
colnames(df) <-c("Method","Values")
data_matrix <- as.data.frame(matrix(nrow = 0,ncol = 4))
method <- unique(df$Method)

for (d in 1:length(method)) {
  val <- subset(df,Method==method[d])
  statix.val <- statix(val$Values)
  
  res <- data.frame(Method=method[d],
                    st_dev=statix.val$st_dev,
                    mean=statix.val$mean,
                    median=statix.val$median)
  data_matrix <- rbind(data_matrix,res)
}

final.df$PercStable <- data_matrix$mean
final.df_sd$PercStable <- data_matrix$st_dev
final.df_median$PercStable <- data_matrix$median

#-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-#
#D_index
df <- dist2[c("Method", "D_index")]
head(df,3)
colnames(df) <-c("Method","Values")
data_matrix <- as.data.frame(matrix(nrow = 0,ncol = 4))
method <- unique(df$Method)

for (d in 1:length(method)) {
  val <- subset(df,Method==method[d])
  statix.val <- statix(val$Values)
  
  res <- data.frame(Method=method[d],
                    st_dev=statix.val$st_dev,
                    mean=statix.val$mean,
                    median=statix.val$median)
  data_matrix <- rbind(data_matrix,res)
}

final.df$D_index <- data_matrix$mean
final.df_sd$D_index <- data_matrix$st_dev
final.df_median$D_index <- data_matrix$median

#-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-#
#Distance
df <- dist2[c("Method", "Dist")]
head(df,3)
colnames(df) <-c("Method","Values")
data_matrix <- as.data.frame(matrix(nrow = 0,ncol = 4))
method <- unique(df$Method)

for (d in 1:length(method)) {
  val <- subset(df,Method==method[d])
  statix.val <- statix(val$Values)
  
  res <- data.frame(Method=method[d],
                    st_dev=statix.val$st_dev,
                    mean=statix.val$mean,
                    median=statix.val$median)
  data_matrix <- rbind(data_matrix,res)
}



final.df$Distance <- data_matrix$mean
final.df_sd$Distance <- data_matrix$st_dev
final.df_median$Distance <- data_matrix$median

final.df <- final.df[order(final.df$Dist),]

#-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-#

head(final.df,3)


colnames(final.df) <- c("Method", "RSV","PS","D_index","Dist")
colnames(final.df_sd) <- c("Method", "RSV_sd","PS_sd","D_index_sd" ,"Dist_sd")
colnames(final.df_median) <- c("Method", "RSV_median","PS_median", "D_index_median","Dist_sd")

df.for.plot <- cbind(final.df,final.df_sd[c(2,3,4,5)], final.df_median[c(2,3,4,5)])
head(df.for.plot,3)


write.csv(dist2, "ALL Values Distance 35.csv")
write.csv(final.df, "Summary Values Distance 35.csv")
opendir()

#-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-#

library(scales)
library(plot3D)

#All Values

n1 <- length(unique(dist2$Method))
colors <- hue_pal()(n1) 
colors <- colors[as.numeric(as.factor(dist2$Method))]
colors

# x, y and z coordinates
x <- sep.l <- dist2$SpeciesRangeChange
y <- pet.l <- dist2$PercStable
z <- sep.w <- dist2$D_index

jpeg("Summary - All Data.jpg", units="px", width=8000, height=4000, res=600) ### creo il file, puoi modificare i parametri
scatter3D(x, y, z, bty = "g", colkey = FALSE, main ="Summary - All Data",
          colvar = NULL, col = colors,  pch = 19, cex = 0.5,
          phi = 35,
          theta = 65,
          type = "h", #or g or p or h
          ticktype = "detailed",
          xlab = "Range Size Variation", 
          ylab = "Perc. Stable", zlab = "D - Index",
          xlim = c(-10,10), ylim = c(0,100), zlim = c(0,1))
dev.off()

#-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-#

#Mean Values

n1 <- length(unique(final.df$Method))
colors <- hue_pal()(n1) 
colors <- colors[as.numeric(as.factor(final.df$Method))]
colors

# x, y and z coordinates
x <- sep.l <- final.df$RSV
y <- pet.l <- final.df$PS
z <- sep.w <- final.df$D_index

jpeg("Summary - Mean Values.jpg", units="px", width=8000, height=4000, res=600) ### creo il file, puoi modificare i parametri
scatter3D(x, y, z, bty = "g", colkey = FALSE, main ="Summary - Mean Values",
          colvar = NULL, col = colors,  pch = 19, cex = 0.5,
          phi = 35,
          theta = 65,
          type = "h", #or g or p
          ticktype = "detailed",
          xlab = "Range Size Variation", 
          ylab = "Perc. Stable", zlab = "D - Index",
          xlim = c(-10,10), ylim = c(0,100), zlim = c(0,1))
dev.off()
opendir()

