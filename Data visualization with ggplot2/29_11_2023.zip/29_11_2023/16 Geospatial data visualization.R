


# Introduction to geospatial data analysis in R



# Explore a vector dataset


library(sf)
setwd("C:/Users/david/Documents/ggplot2/geospatial_data")
mrc <- st_read("data/mrc.shp")

# The bounding box and a detailed description of the CRS can be accessed separately using 
# the st_bbox and st_crs functions:

st_bbox(mrc)
st_crs(mrc)


# Let us look at the first few rows of the data

class(mrc)
head(mrc)
str(mrc)

# An sf object is a specialized data.frame where each line contains data associated with a 
# geometry element (or simple feature, hence the package name), which is described in the 
# geometry column. The most common feature types are:
#---POINT: Coordinates (x, y) of a point.
#---LINESTRING: Sequence of points connected by length segments.
#---POLYGON: Sequence of points creating a closed simple polygon.
#---MULTIPOINT, MULTILINESTRING ou MULTIPOLYGON: Dataset where each feature can be composed of multiple points, linestrings or polygons.



# The plot function applied to an sf object creates a map for each field in the dataset.
plot(mrc)



# To plot a single variable, you need to select the corresponding column. 
# To show a map without data variables, you can select the geometry column. 
# The axes = TRUE parameter tells R to show coordinate axes.

plot(mrc["geometry"], axes = TRUE)
# or...
plot(mrc$geometry, axes = TRUE)


# Create a spatial object from a data frame
# The plots.csv file contains data from forest inventory plots of the Québec Department of Forests, 
# Wildlife and Parks (MFFP), including the plot ID, latitude and longitude, survey date, 
# cover type (deciduous, mixed or coniferous) and canopy height class.
plots <- read.csv("data/plots.csv")
head(plots)

# We can convert this data to an sf object with st_as_sf. The coords argument specifies which 
#columns hold the X and Y coordinates, while the crs argument defines the coordinate reference 
# system (here, it is set to the same CRS as the MRC dataset).

plots <- st_as_sf(plots, coords = c("long", "lat"), crs = st_crs(mrc))
plot(plots["geometry"])


# Plot bsic map and vegetation data
plot(mrc$geometry, axes = TRUE)
plot(plots["geometry"], add=TRUE)


# Customize maps with ggplot2

# While the plot function is useful to get an overview of a spatial dataset, 
# other packages provide more customization options to create publication-quality maps. 
# In this section, we will see how a widely-used R graphics package, ggplot2, also supports 
# mapping of spatial datasets.

library(ggplot2)

ggplot(data = plots, aes(x = height_cls, fill = cover_type)) + 
  geom_bar() +
  labs(title = "Forest inventory plots", x = "Height class", 
       y = "Count", fill = "Cover type")


# We will convert the mrc polygons into a Lambert conical conformal projection centered on Quebec 
# (EPSG:6622), using st_transform.
mrc_proj <- st_transform(mrc, crs = 6622)
plot(mrc["geometry"], axes = TRUE)
plot(mrc_proj["geometry"], axes = TRUE)


ggplot(data = mrc_proj) +
  geom_sf()



# To add multiple spatial layers to the same map, we simply add more geom_sf layers, 
# which can be based on different datasets (specifying the data argument in each geom). 
# In the code below, we add a point layer for the forest inventory plots, assigning the color aesthetic to cover type. We also use theme_set(theme_bw()) to change from the default grey theme to the black and white theme in all future plots.

theme_set(theme_bw())
ggplot() +
  geom_sf(data = mrc_proj) +
  geom_sf(data = plots, aes(color = cover_type), size = 1)










# Additional information can be retrived at:
# https://pmarchand1.github.io/atelier_rgeo/rgeo_workshop.html#create_a_spatial_object_from_a_data_frame


