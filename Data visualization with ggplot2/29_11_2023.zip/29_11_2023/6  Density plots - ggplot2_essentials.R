

# Density plots
library(ggplot2)

# A Density Plot visualises the distribution of data over a continuous interval or time period. 
# This chart is a variation of a Histogram that uses kernel smoothing to plot values, allowing 
# for smoother distributions by smoothing out the noise. The peaks of a Density Plot help display 
# where values are concentrated over the interval.

# This R tutorial describes how to create a density plot using R software and ggplot2 package.


# Prepare the data
#This data will be used for the examples below :
  
set.seed(1234)
df <- data.frame(
  sex=factor(rep(c("F", "M"), each=200)),
  weight=round(c(rnorm(200, mean=55, sd=5),
                 rnorm(200, mean=65, sd=5)))
)
head(df)


# Basic density...
p <- ggplot(df, aes(x=weight)) + 
  geom_density()
p

# Add mean line...
p+ geom_vline(aes(xintercept=mean(weight)),
              color="blue", linetype="dashed", size=1)



# Change density plot line types and colors

# Change line color and fill color
ggplot(df, aes(x=weight))+
  geom_density(color="darkblue", fill="lightblue")

# Change line type
ggplot(df, aes(x=weight))+
  geom_density(linetype="dashed")



# Change density plot colors by groups
# Calculate the mean of each group


library(plyr)
mu <- ddply(df, "sex", summarise, grp.mean=mean(weight))
head(mu)

# Change line colors (Density plot line colors can be automatically controlled by the levels of sex)
# Change density plot line colors by groups...
ggplot(df, aes(x=weight, color=sex)) +
  geom_density()

# Add mean lines...
p<-ggplot(df, aes(x=weight, color=sex)) +
  geom_density()+
  geom_vline(data=mu, aes(xintercept=grp.mean, color=sex),
             linetype="dashed")
p

# It is also possible to change manually density plot line colors using the functions :
# scale_color_manual() : to use custom colors
# scale_color_brewer() : to use color palettes from RColorBrewer package
# scale_color_grey() : to use grey color palettes

# Use custom color palettes...
p+scale_color_manual(values=c("#999999", "#E69F00", "#56B4E9"))

# Use brewer color palettes...
p+scale_color_brewer(palette="Dark2")

# Use grey scale...
p + scale_color_grey() + theme_classic()


# Change fill colors
# Change density plot fill colors by groups...
ggplot(df, aes(x=weight, fill=sex)) +
  geom_density()

# Use semi-transparent fill...
p<-ggplot(df, aes(x=weight, fill=sex)) +
  geom_density(alpha=0.4)
p

# Add mean lines...
p+geom_vline(data=mu, aes(xintercept=grp.mean, color=sex),
             linetype="dashed")


# It is also possible to change manually density plot fill colors using the functions :
# scale_fill_manual() : to use custom colors
# scale_fill_brewer() : to use color palettes from RColorBrewer package
# scale_fill_grey() : to use grey color palettes


# Use custom color palettes
p+scale_fill_manual(values=c("#999999", "#E69F00", "#56B4E9"))

# use brewer color palettes
p+scale_fill_brewer(palette="Dark2")

# Use grey scale
p + scale_fill_grey() + theme_classic()


# Change the legend position (The allowed values for the arguments legend.position are : “left”,“top”, “right”, “bottom”)

p + theme(legend.position="top")
p + theme(legend.position="bottom")
p + theme(legend.position="none") # Remove legend


# Combine histogram and density plots
# The histogram is plotted with density instead of count values on y-axis
# Overlay with transparent density plot

# Histogram with density plot...
ggplot(df, aes(x=weight)) + 
  geom_histogram(aes(y=..density..), colour="black", fill="white")+
  geom_density(alpha=.2, fill="#FF6666") 

# Color by groups...
ggplot(df, aes(x=weight, color=sex, fill=sex)) + 
  geom_histogram(aes(y=..density..), alpha=0.5, 
                 position="identity")+
  geom_density(alpha=.2) 



# Split the plot in multiple panels with facets

p<-ggplot(df, aes(x=weight))+
  geom_density()+facet_grid(sex ~ .)
p

# Add mean lines
p+geom_vline(data=mu, aes(xintercept=grp.mean, color="red"),
             linetype="dashed")



# Customized density plots

# Basic density...
ggplot(df, aes(x=weight, fill=sex)) +
  geom_density(fill="gray")+
  geom_vline(aes(xintercept=mean(weight)), color="blue",
             linetype="dashed")+
  labs(title="Weight density curve",x="Weight(kg)", y = "Density")+
  theme_classic()

# Change line colors by groups...
p<- ggplot(df, aes(x=weight, color=sex)) +
  geom_density()+
  geom_vline(data=mu, aes(xintercept=grp.mean, color=sex),
             linetype="dashed")+
  labs(title="Weight density curve",x="Weight(kg)", y = "Density")

p + scale_color_manual(values=c("#999999", "#E69F00", "#56B4E9"))+
  theme_classic()


# Change line colors manually

# Continuous colors
p + scale_color_brewer(palette="Paired") + theme_classic()

# Discrete colors
p + scale_color_brewer(palette="Dark2") + theme_minimal()

# Gradient colors
p + scale_color_brewer(palette="Accent") + theme_minimal()





# Additional information can be retrived at
# STHDA - Statistical tools for high-throughput data analysis
# http://www.sthda.com/english/wiki/ggplot2-essentials













