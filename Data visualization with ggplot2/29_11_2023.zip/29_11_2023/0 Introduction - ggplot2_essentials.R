

#STHDA - Statistical tools for high-throughput data analysis
#http://www.sthda.com/english/wiki/ggplot2-essentials


# Installation
#install.packages('ggplot2')

# Loading
library(ggplot2)

#The data set mtcars is used in the examples below:
# mtcars : Motor Trend Car Road Tests.
# Description: The data comprises fuel consumption and 10 aspects of automobile design and performance 
# for 32 automobiles (1973 - 74 models).
# Format: A data frame with 32 observations on 3 variables
# Load the data

data(mtcars)
df <- mtcars[, c("mpg", "cyl", "wt")]
head(df)



# INDEX
# 1 - qplot(): Quick plot with ggplot2
# 2 - Box plots
# 3 - Violin plots
# 4 - Dot plots
# 5 -  
# 6 - 
# 7 - 
# 8 - 
# 9 - 
# 10 - 
# 11 - 
# 12 - 
# 13 - 
# 14 - 
# 15 - 
# 16 - 
# 17 - 
# 18 - 
# 19 - 
# 20 - 
# 21 - 
# 22 - 
# 23 - 
# 24 - 
# 25 - 
# 26 - 
# 27 - 




