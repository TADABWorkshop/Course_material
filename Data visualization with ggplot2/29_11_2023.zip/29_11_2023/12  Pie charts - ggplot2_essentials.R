

#  Pie chart
library(ggplot2)
library(scales)

# A pie chart is a type of graph representing data in a circular form, with each slice 
# of the circle representing a fraction or proportionate part of the whole. 
# All slices of the pie add up to make the whole equaling 100 percent and 360 degrees.
# This R tutorial describes how to create a pie chart for data visualization using R software and ggplot2 package.
# The function coord_polar() is used to produce a pie chart, which is just a stacked bar chart in polar coordinates.



# Create some data
df <- data.frame(
  group = c("Male", "Female", "Child"),
  value = c(25, 25, 50)
)
head(df)


# Use a barplot to visualize the data
#Barplot...
bp<- ggplot(df, aes(x="", y=value, fill=group))+
  geom_bar(width = 1, stat = "identity")
bp


# Create a pie chart
pie <- bp + coord_polar("y", start=0)
pie


# Change the pie chart fill colors
# It is possible to change manually the pie chart fill colors using the functions :
# scale_fill_manual() : to use custom colors
# scale_fill_brewer() : to use color palettes from RColorBrewer package
# scale_fill_grey() : to use grey color palettes


# Use custom color palettes
pie + scale_fill_manual(values=c("#999999", "#E69F00", "#56B4E9"))


# # use brewer color palettes
pie + scale_fill_brewer(palette="Dark2")


# use blue color palettes
pie + scale_fill_brewer(palette="Blues")+
  theme_minimal()


# Use grey scale
pie + scale_fill_grey() + theme_minimal()



# Create a pie chart from a factor variable
# PlantGrowth data is used
head(PlantGrowth)

# Create the pie chart of the count of observations in each group
ggplot(PlantGrowth, aes(x=factor(1), fill=group))+
  geom_bar(width = 1)+
  coord_polar("y")




# Customized pie charts
# Create a blank theme...
blank_theme <- theme_minimal()+
  theme(
    axis.title.x = element_blank(),
    axis.title.y = element_blank(),
    panel.border = element_blank(),
    panel.grid=element_blank(),
    axis.ticks = element_blank(),
    plot.title=element_text(size=14, face="bold")
  )


# Apply blank theme...
library(scales)
pie + scale_fill_grey() +  blank_theme +
  theme(axis.text.x=element_blank()) +
  geom_text(aes(y = value/3 + c(0, cumsum(value)[-length(value)]), 
                label = percent(value/100)), size=5)


# Use brewer palette...
pie + scale_fill_brewer("Blues") + blank_theme +
  theme(axis.text.x=element_blank())+
  geom_text(aes(y = value/3 + c(0, cumsum(value)[-length(value)]), 
                label = percent(value/100)), size=5)






# Additional information can be retrived at
# STHDA - Statistical tools for high-throughput data analysis
# http://www.sthda.com/english/wiki/ggplot2-essentials

