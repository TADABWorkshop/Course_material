

# Save ggplot outputs
library(ggplot2)

######
# Custom function to open current directory
opendir <- function(dir = getwd()){
  if (.Platform['OS.type'] == "windows"){
    shell.exec(dir)
  } else {
    system(paste(Sys.getenv("R_BROWSER"), dir))
  }
}
######

getwd()
dir.create('ggplot_outputs')
setwd('ggplot_outputs')
opendir()

# print(): print a ggplot to a file
# To print directly a ggplot to a file, the function print() is used

# Print the plot to a pdf file...
pdf("myplot.pdf")
myplot <- ggplot(mtcars, aes(wt, mpg)) + geom_point()
print(myplot)
dev.off()
opendir()
  

# For printing to a png file, use:
png("myplot.png")
myplot <- ggplot(mtcars, aes(wt, mpg)) + geom_point()
print(myplot)
dev.off()
opendir()


# For printing to a jpg file and specify
Sys.sleep(1)
jpeg("3.PRESENT.jpg", units="px", width=3200, height=3200, res=600) ### creo il file, puoi modificare i parametri
print(pres_plot)
dev.off()

Sys.sleep(1)


# ggsave: save the last ggplot
# ggsave is a convenient function for saving the last plot that you displayed. 
# It also guesses the type of graphics device from the extension. This means the only argument you need to supply 
# is the filename.


# It's also possible to make a ggplot and to save it from the screen using the function ggsave()

# 1. Create a plot
# The plot is displayed on the screen...
ggplot(mtcars, aes(wt, mpg)) + geom_point()

# 2. Save the plot to a pdf...
ggsave("myplot2.pdf")
opendir()




# Save multiple images at the same time
# Use mtcars as example

mtcars

# create a scatter plot mpg-cyl...
myplot <- ggplot(mtcars, aes(wt, mpg)) + geom_point()
myplot

# save the result...
png("wt-mpg.png")
print(myplot)
dev.off()
opendir()


# Create and save all scatter plot...

list_names <- colnames(mtcars)


for (a in 1:length(list_names)) {
  for (b in 1:length(list_names)) {

name_a <- list_names[a]
name_b <- list_names[b]
mtcars2 <- mtcars[,c(paste0(name_a,''),paste0(name_b,''))]
colnames(mtcars2) <- c('a','b')
myplot_2 <- ggplot(mtcars2, aes(mtcars2$a,mtcars2$b)) + 
  geom_point() +
  xlab(paste0(name_a,'')) + 
  ylab(paste0(name_b,''))

plot(myplot_2)
Sys.sleep(2)

# save the result...
png(paste0('mtcars_plot_',name_a,'_vs_',name_b,'.png'))
print(myplot_2)
dev.off()
opendir()
  }
}












