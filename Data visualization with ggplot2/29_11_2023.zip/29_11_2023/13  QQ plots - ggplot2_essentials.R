


#  QQ plots (quantile-quantile plot)
library(ggplot2)

# In statistics, a QQ plot (quantile-quantile plot) is a probability plot, 
# a graphical method for comparing two probability distributions by plotting their quantiles against each other.
# A point (x, y) on the plot corresponds to one of the quantiles of the second distribution (y-coordinate) plotted against
# the same quantile of the first distribution (x-coordinate). 
# This defines a parametric curve where the parameter is the index of the quantile interval.

# QQ plots is used to check whether a given data follows normal distribution.
# QQ plots is used to comparre two probability distributions by plotting their quantiles against each other 

# This R tutorial describes how to create a qq plot (or quantile-quantile plot) using R software and ggplot2 package.
# The function stat_qq() or qplot() can be used.





# Prepare the data
# mtcars data sets are used in the examples below


# Create normal distribution
x <- seq(0, 32, by = 0.5)
y <- dnorm(x, mean = 10.0, sd = 1.0)
df <- data.frame(x_val=x, y_val=y)
plot(x,y, main = "Normal Distribution", col = "blue")

# Basic qq plots

# Solution 1...
qplot(sample = x_val , data = df)

# Solution 2...
ggplot(df, aes(sample=x_val))+stat_qq()


# mtcars data sets are used in the examples below.
# Prepare the data...
# Convert cyl column from a numeric to a factor variable...
mtcars$cyl <- as.factor(mtcars$cyl)
head(mtcars)


# Basic qq plots

# Solution 1...
qplot(sample = mpg, data = mtcars)

# Solution 2...
ggplot(mtcars, aes(sample=mpg))+stat_qq()


# Change qq plot point shapes by groups
# In the R code below, point shapes are controlled automatically by the variable cyl.
# You can also set point shapes manually using the function scale_shape_manual()

# Change point shapes by groups...
p<-qplot(sample = mpg, data = mtcars, shape=cyl)
p

# Change point shapes manually...
p + scale_shape_manual(values=c(1,17,19))


# Change qq plot colors by groups

# Change qq plot colors by groups
p<-qplot(sample = mpg, data = mtcars, color=cyl)
p


# It is also possible to change manually qq plot colors using the functions :
# scale_color_manual() : to use custom colors
# scale_color_brewer() : to use color palettes from RColorBrewer package
# scale_color_grey() : to use grey color palettes

# Use custom color palettes...
p+scale_color_manual(values=c("#999999", "#E69F00", "#56B4E9"))

# Use brewer color palettes...
p+scale_color_brewer(palette="Dark2")

# Use grey scale...
p + scale_color_grey() + theme_classic()


# Change the legend position
p + theme(legend.position="top")
p + theme(legend.position="bottom")
p + theme(legend.position="none") # Remove legend



# Customized qq plots

# Basic qq plot...
qplot(sample = mpg, data = mtcars)+
  labs(title="Miles per gallon \n according to the weight",
       y = "Miles/(US) gallon")+
  theme_classic()

# Change color/shape by groups...
p <- qplot(sample = mpg, data = mtcars, color=cyl, shape=cyl)+
  labs(title="Miles per gallon \n according to the weight",
       y = "Miles/(US) gallon")
p + theme_classic()



# Change colors manually

# Continuous colors...
p + scale_color_brewer(palette="Blues") + theme_classic()

# Discrete colors...
p + scale_color_brewer(palette="Dark2") + theme_minimal()

# Gradient colors...
p + scale_color_brewer(palette="RdBu")








# Additional information can be retrived at
# STHDA - Statistical tools for high-throughput data analysis
# http://www.sthda.com/english/wiki/ggplot2-essentials






