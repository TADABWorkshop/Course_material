# TADAP workshop, Uni Pisa, 2023

library (readxl)
# Part 3. Incorporating phylogeny
dat = as.data.frame(read_xlsx("Data.xlsx", 5))
str (dat)

# species names should be row names
rownames (dat) = dat[,1]
#dat = dat[,-1]

# uploading phylogeny
library (ape)
phyl = read.tree (file = "DaPhnE_01.tre") # reads the phylogeny

summary (phyl) # the phylogenetic tree contains 5122 species

x11 ()
plot (phyl) # plots the tree

# pruning the tree - we need information only on our species
# IMPORTANT: the row names should be the species names

# checking for concordance between the tree and the data set
library (geiger)
obj = name.check(phyl, dat)

summary (obj)
obj$tree_not_data # species present in the tree, but not in the data
obj$data_not_tree # species present in the data set, but missing in the tree
# "character(0)" indicates that there is no mismatch between the tree and data set 

phyl.upd = drop.tip(phyl, obj$tree_not_data) # prunes the tree
summary (phyl.upd)

name.check(phyl.upd, dat) # check the names in the tree and in the data set

# plotting the pruned tree
# option 1
plot (phyl.upd)


# option 2
library (phytools)
plotTree(phyl.upd,type="fan",fsize=0.7,lwd=1,
         ftype="i")

# the current methods work with binary trees (i.e. one node - two species)
is.binary.tree (phyl.upd) # it is not a binary tree

phyl.upd2 = multi2di(phyl.upd) # solving 'multiple' nodes
is.binary.tree(phyl.upd2) # ok


# Phylogenetic signal for continuous traits
# Blomberg's K-statistics: the higher the K-value, the stronger the phylogenetic signal (d)
library (picante)

phymsig = multiPhylosignal(dat[, 2:9], phyl.upd2)
phymsig
# some trait values are not randomly distributed over the species - low p-values indicate the presence of phyl. signal in this trait

# plotting the traits on phylogeny:
# option 1

x11 ()
dotTree(phyl.upd2, dat[4],length=10,ftype="i")

# option 2
plotTree.barplot(phyl.upd2, dat[4])

# option 3
# ggtree: https://4va.github.io/biodatasci/r-ggtree.html


# Phylogenetic generalized least squares 
# Brownian motion model - "random walk", i.e. traits changes randomly in trait
m1a = lm (SLA ~ Elevation, data=dat)
summary (m1a)

-0.7061*100 # every 100 m of elevation SLA decreased by 0.71 mm2/mg

# we violate the assumption that the data points are independent
# thus, we need another model accounting for phylogenetic relatedness
library (nlme)

m1b = gls (SLA ~ Elevation, correlation = corBrownian(1, phyl.upd2, form=~Species),
          data = dat, method = "ML")
summary (m1b)

-0.58*100 # every 100 m of elevation SLA decreased by 0.56 mm2/mg
# IMPORTANT: accounting for phylogenetic signal can result in different model estimates

x11 ()
plot (allEffects(m1b, partial.residuals=T))

# model assumptions
x11()
plot (m1b) # homogeneity of variance
qqnorm (m1b) # normality of residuals

plot (residuals(m1b) ~ dat$Elevation)

# The Brownian motion models assumptions can be relaxed.
# The most simple generalization of the Brownian model is one with one additional parameter
# to scale the expected covariance under pairs of species.
# This model is called the lambda model of Pagel (Pagel's lambda).
# When lambda = 0 the covariance between species is zero and this corresponds to a 'normal'
#  regression. By contrast, when lambda = 1, the evolution of the residual error is Brownian.

m2a = gls(SLA ~ Elevation, correlation = corPagel(1, phyl.upd2, form=~Species),
          data = dat, method = "ML")
summary (m2a)

# model assumptions
x11 ()
plot (m2a) # homogeneity of variance
qqnorm (m2a) # normality of residuals

plot(m2a, resid(., type="n")~fitted(.), main="Normalized Residuals v Fitted Values",
     abline=c(0,0))

# checking the largest residuals
res[which.max(res)]