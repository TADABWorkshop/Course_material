# TADAP workshop, Uni Pisa, 2023
# Linear models - practice ------------------------------------------------
library (readxl)
library (dplyr)
library (GerminaR) # a specific package that calculates seed traits based on exp. data
library (plotrix)
library (emmeans) # post-hoc tests for linear models
library (multcompView) # post-hoc tests for linear models
library (effects) # visualize model effects
library (ggplot2)


# Example 1 Group comparison ----------------------------------------------
# Differences in final germination percentage among six tested temperatures in Anthoxantum alpinum
dat = as.data.frame (read_xlsx("data.xlsx", 7))
str (dat)

# calculate seed germination percentage
gerind = ger_summary(SeedN = "seeds", evalName = "D", data=dat)
gerind

# summary statistics for the data 
gerindsum = gerind %>% 
  group_by (temp) %>% 
  summarize_all(funs(mean, sd, std.error), na.rm = TRUE)%>% 
  as.data.frame () 

# subsetting data for germination percentage only
datantalp = gerind[,c(2,6)]

# plotting the data
x11()
ggplot (datantalp, aes (x=temp, y=grp))+
  geom_boxplot (fill = "grey") +         
  labs(x = "Test temperatures", y="Seed germination percentage, %")+
  theme_classic(base_size = 18)    

# Are there statistically significant differences in germination percentage among the test temperatures?
# lm framework also works with factors (group comparison) the output is identical to ANOVA

# linear regression
m1 = lm (grp ~ as.factor (temp), data=datantalp)
summary (m1)

summary (aov (grp ~ as.factor (temp), data=datantalp))

# It is recommended to check the assumptions BEFORE you take a look at the output
# Assumptions
par (mfrow = c(2,2))
plot (m1)

# group comparison
summary (m1)
# estimate is a mean germination percentage at each test temperature:
# intercept - is GRP at 10/2 degree. p-value shows that it is significantly different from zero
# temp14/6 is the difference between 10/2 and 14/6. p-value shows that it is different from 10/2

# Post-hoc test
# the model output shows whether temperatures 14/6, 18/10, 22/14, 26/18 and 30/22 are different from the 
# reference ('control') group. But what about the differences among the groups? To answer this question,
# we need to perform a post-hoc test:

# NB! p-values should be adjusted during multiple comparisons, thus we need to use the adjusting argument
postm1 = emmeans (m1,
                  pairwise ~ temp,
                  adjust = "Tukey") #Tukey-adjusted comparisons 

postm1


# Example 2 Regression with an interaction term ---------------------------------------------------------------
# Mean germination time along elevational gradient tested at six different temperatures
# read the data
df = as.data.frame (read_xlsx("data.xlsx", 8))

# check the data
str (df)
summary (df)

# convert the data
df$MGT = as.numeric (df$MGT)
df$Temp = as.factor (df$Temp)

str (df)
summary (df)

# Seeds were collected once from the most optimal ecological conditions of a species
# Data set includes lowland, montane and alpine species

# MGT - mean germination time 
# Elevation - the elevation of collection sites. 
# The temperatures were coded as follows:
# A - 10/2
# B - 14/6
# C - 18/10
# D - 22/14
# E - 26/18
# F - 30/22

# Lets plot the data
# all data in one figure
x11 ()
ggplot (df, aes (x=Elevation, y=MGT, fill=Temp,  color=Temp))+
  geom_point() +
  geom_smooth(method = "lm") +
  theme_bw ()
# ggplot2 excluded the NAs automatically

# faceting
ggplot (df, aes (x=Elevation, y=MGT))+
  geom_point() +
  geom_smooth(method = "lm") +
  facet_grid(Temp ~ ., ) +# makes a separate graph for each temperature
  theme_bw ()


# run the models
# simple 'slope + intercept model's - a general effect of elevation on MGT regardless temperature
m4a = lm (MGT ~  Elevation, data=df) 
summary (m4a)

# including a quadratic term I(variable^2) - some relationships may be non-linear
m4b = lm (MGT ~ Elevation + I(Elevation^2), data=df)
summary (m4b)

# slopes for every test temperature
m4c = lm (MGT ~ Elevation*Temp, data=df) # this syntax is equal to MGT ~ Elevation + Temp + Elevation:Temp
summary (m4c)

# intercept - the MGT at 0 m a.s.l
# Elevation - the slope for the temperature A (10/2)
# Temp B, C, D, etc. are differences as compared to the intercept.
# Elevation:Temp A, B, C., etc. are different slopes for each temperature
# They are all significant, thus the intercepts for 6 test temperatures are different

# Elevation:TempA etc. are differences to the slope for temp A (Elevation).
# They are not significant, thus the slopes, i.e. the nature and the magnitude of MGT ~ elevation relationship 
# is the same among all test temperatures

# The standard (g)lm outputs are messy...

# a post-hoc test for intercepts (temperatures in this case)
emmeans (m4c, pairwise ~ Temp, adjust = "Tukey")

# are slopes significantly different from zero?
pp = lstrends (m4c, ~ Temp, var = "Elevation")
summary(pp, infer=c(TRUE,TRUE),null=0)

# The ecological interpretation is that germination speed increases with increasing elevation regardless test temperatures
# That is, seeds of alpine species germinate slowly.

# model assumptions
par (mfrow = c(2,2))
plot (m4c)

# another way to look at the residuals;
plot (allEffects(m4c, partial.residuals=T))

hist (log(df$MGT))

# before you try another model, e.g. glm for Poisson data, try to transform the data
# log- or sqrt-transformation might work out
m4d = lm (log(MGT) ~ Elevation*Temp, data=df)
summary (m4d)

x11 ()
par (mfrow = c(2,2))
plot (m4d)

plot (allEffects(m4d, partial.residuals=T))

#visualizing interaction effects can be easily done this way:
library (interactions)

interact_plot(m4c, pred = Elevation, modx = Temp,
                    interval = TRUE,
                    plot.points = TRUE,
                    y.label = "type your label here",
                    x.label = "type your label here") +
                   # scale_x_continuous(name="", 
                    # breaks = scales::pretty_breaks(n = 10)) + 
  theme_classic (base_size = 14)

#This graph is almost identical the graph plotted by ggplot, because the latter 
#uses lm () to estimate the intercepts and slopes. In complex models, the estimates 
#might be contrastingly different from the ggplot graphs. Thus, plot 1) raw data and
# 2) regression lines based on the model estimates


# Example 3 Multiple regression -------------------------------
dat = as.data.frame(read_xlsx("Data.xlsx", 4))
str (dat)

# species names should be row names if you want them to be in the graph
rownames (dat) = dat[,1]
dat = dat[,-1]

# Let's get an idea how the variables are related + characteristics of variables
# Scatter plot matrix
library (PerformanceAnalytics)

x11 ()
chart.Correlation(dat[,2:9], histogram=TRUE, pch=19)


# Principal component analysis
library (factoextra)
library (FactoMineR)

res.pca = PCA(dat[,2:9], scale.unit = FALSE, ncp = 3, graph = TRUE) 
# variables are on different scales! 1 meter of elevation is equal to 1 mg of seed size
# From ecological point of view, 100 m of elevation is not a big difference, 
# but 100 mg of seed size (1 vs. 100 mg) is a lot of variability in the function. 

# re-scale the variables
res.pca = PCA(dat[,2:9], scale.unit = TRUE, ncp = 3, graph = TRUE)

# eigenvalues/importance of the axes
fviz_eig(res.pca, addlabels = TRUE, ylim = c(0, 50))

# biplot
fviz_pca_biplot(res.pca, repel = TRUE) # avoid text overlapping (slow if many points)
# more on PCA: http://www.sthda.com/english/articles/31-principal-component-methods-in-r-practical-guide/112-pca-principal-component-analysis-essentials/

# the model
# Note that we scale variables as they are on very different scales
# Scaling does not effect the p-values and makes output interpretation easier
m1 = lm (SLA ~ scale (CanopyHeight) + scale(SeedMass) + scale(TV) + 
              scale (EpiMerino) + scale (DormRank) +
              scale (MGT) + scale (SYN), data=dat)
?scale ()
par (mfrow = c(2,2))
plot (m1)
plot (allEffects(m1, partial.residuals=T))

summary (m1)
anova (m1)

# model selection: some predictors are not important/significant.
# how the output will look like if you exclude the non-significant predictors?
library (MASS)

fit = stepAIC(m1,direction="both",trace=0) # both backward and forward selection
fit

# the most parsimonious model
m2b = lm (SLA ~ scale(TV) + scale(DormRank) + scale(MGT) + scale(SYN), data=dat)
summary (m2b)


# do not forget to check for autocorrelation!
library (car)
vif (m2b) # values >5 are supposed to indicate autocorrelation among the predictors.

# Caution!!! Model selection is considered as p-hacking, thus be very careful with this approach
# More on the topic: https://en.wikipedia.org/wiki/Data_dredging


# a few more ways to work with regression outputs
library (sjPlot)
library (sjlabelled)
library (sjmisc)
library (ggplot2)

tab_model (m2b) # this is a ready table for the 'Results'

theme_set (theme_classic(base_size = 18))

x11 ()
plot_model (m2b, show.values = T, 
            axis.labels = c("TV", "DormRank", "MGT", "SYN"),
            title = "Title",
            line.size = 1,
            dot.size = 2.5,
            value.size = 6, 
            value.offset = 0.4) 