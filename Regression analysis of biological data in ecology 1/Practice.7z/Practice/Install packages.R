# TADAP workshop, Uni Pisa, 2023
# install packages

install.packages(c("ape", "car","corrplot", "DHARMa", "dplyr","drc","effects", "emmeans",
                   "factoextra", "FactoMineR", "geiger", "GerminaR","ggthemes", 
                   "interactions","knitr","MASS", "multcompView", 
                   "patchwork", "PerformanceAnalytics", "phytools", 
                   "picante", "plotrix", "readr", "readxl", 
                   "sjPlot","sjlabelled", "sjmisc",
                    "tibble", "tidyverse"))