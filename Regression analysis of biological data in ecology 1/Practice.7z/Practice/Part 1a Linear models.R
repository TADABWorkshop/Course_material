# TADAP workshop, Uni Pisa, 2023

# Part 1. (Gentle) introduction to linear models 

# The ultimate two aims of any science are
# 1) to explain the past and present patterns
# 2) predict the future.
# Linear models can do both
library (readxl)
library (corrplot) # plots correlation matrices
library (ggthemes) # a few complete ggplot2 themes  
library (ggplot2)

# What is the relationship among elevation and temperature in the Bavarian Alps?

# read the data
climdat = as.data.frame(read_xlsx("Data.xlsx", 3))
climdat

# NB! read_xlsx () function creates a 'tibble', an extended data frame 
# that might not be compatible with some functions. 
# It can be easily converted into matrix (as.matrix (dat) or data frame (as.data.frame ()).)

# Always check the structure of your data BEFORE the analysis.
# This is where most of the problems with R appear.

str (climdat)
summary (climdat) # several numeric variables were uploaded as characters

# transforming all columns to numeric variables:
climdat[,2:22] = data.matrix(climdat[,2:22]) # convert the df to matrix
climdat[,2:22] = as.numeric(unlist(climdat[,2:22])) # the transformation

str (climdat)

# plotting the data (Elevation and mean annual temperature (MAT))
x11 ()
ggplot (climdat, aes(x=Elevation, y=MAT))+
  geom_point()+ # scaterplot
  geom_smooth(method = "lm", colour="blue")+ # add a linear regression line to the plot 
  geom_smooth(method = "loess", colour = "red") + # add a non-linear regression line to the plot
  theme_bw() # 'style' your graphs     

# more on ggplot 2 themes: https://ggplot2.tidyverse.org/reference/ggtheme.html


# Visualize more variables 
pairs (climdat[,2:7]) # all variables are tightly correlated with each other

# correlations among the factors (could be used as a separate tool)
cormat = cor(climdat[,2:7], 
             method = c("spearman"), # use Pearson cor. coefficient when you suspect the relationships to be linear 
             use = "pairwise.complete.obs") 

corrplot.mixed(cormat, sig.level = c(.05), insig = "label_sig")

# further reading:
# https://cran.r-project.org/web/packages/corrplot/vignettes/corrplot-intro.html
# http://www.sthda.com/english/wiki/visualize-correlation-matrix-using-correlogram
# http://www.sthda.com/english/wiki/correlation-matrix-a-quick-start-guide-to-analyze-format-and-visualize-a-correlation-matrix-using-r-software


# What is the fundamental difference between correlation and regession (both as statistical tools)?


# Apparently, elevation is strongly negatively correlated with MAT
# Lets quantify this relationship

# Linear regression
# First, we will make some small adjustments
hist (climdat$Elevation)

# the station at 2578 m a.s.l. is a clear outlier and it is better to exclude it from the analysis for now
# Below you will see how it might affect the regression

climdat2 = climdat[1:25,]

# Specify the model
m1 = lm (MAT ~ Elevation, data = climdat2)

# model output
summary (m1)

# plotting the regression line
x11()
plot (MAT ~ Elevation, data = climdat2,
      xlim = c(0,2200), # specify the length of x-axis
      ylim = c (0,11)) # specify the length of y-axis

abline (a =9.967559, b= -0.003779) # add regression line manually

# linear model assumptions
par(mfrow=c(2,2))
plot (m1)

# Assumption 1: Model linearity
# the residuals should be scattered all over the plot
# 'shotgun shot' or 'star sky' pattern - ok

# Assumption 2: the mean of residuals is zero (or close to it)
mean(m1$residuals)

# Assumption 3: Homoscedasticity of residuals or equal variance
# No clear pattern - ok

# Assumption 4: Normality of residuals
# Almost all residuals are located along the line - ok
# There are always some deviations from normality, especially at the line ends

# Assumption 5: Lack of correlation between the explanatory variables and residuals
cor.test(climdat2$Elevation, m1$residuals) # no correlation - ok

# Assumption 6: Positive variance in explanatory variables
var (climdat2$Elevation) # variance is greater than 0 - ok


# influential points
# remember the station at 2578 m a.s.l.?
m2 = lm (MAT ~ Elevation, data = climdat)
summary (m2)

x11 ()
par(mfrow=c(2,2))
plot (m2)
# the point 26 is this very station - a clear influential point that influences the model fit

# we can compare the goodness of fit
summary (m1)
summary (m2)
# compare the adjusted R2 and F - statistic - the second model is better

# Predicting values for elevations with missing observations
newelev = data.frame (Elevation = seq(0,2500,1)) # create a data frame with elevations you need to predict the MATs for 

predict (m1, newdata=newelev) # predict the MATs for new elevations based on the mode

output = as.data.frame (predict (m1, newdata=newelev)) # one small adjustment

# export the data (optionally)
write.csv (output, "MAT_elevation.csv")
