# TADAP workshop, Uni Pisa, 2023

# Generalized linear models  ------------------------------------------------
library (readxl)
library (dplyr)
library (effects)
library (ggplot2)

# Example 1 - Dormancy pattern along elevational gradient
dat = as.data.frame (read_xlsx("data.xlsx", 4))
str (dat)

# let's start with a lm
m1a = lm (DormRank ~ Elevation, data=dat)
summary (m1a)

x11 ()
par (mfrow = c(2,2))
plot (m1a)

hist (dat$DormRank) # binary data do not follow Gaussian distribution

# use correct model - binomial/logistic regression
m1b = glm (DormRank ~ Elevation, family='binomial', data=dat)
summary (m1b)

plot (m1b) # there is no a simple and easy diagnostic solution for glms in the base R

# package DHARMa solves this problem: https://cran.r-project.org/web/packages/DHARMa/vignettes/DHARMa.html
library (DHARMa)

ressim2 = simulateResiduals(m1b)
plot (ressim2) # there are apparently some problems with the residuals
               # the common misconception is to blame the data, but such problems
               # often arise from the fact that we do not consider other predictors

m1c = glm (DormRank ~ Elevation + SLA, family='binomial', data=dat)
summary (m1c)

ressim3 = simulateResiduals(m1c)
plot (ressim3)


# Example 2 Thinking in terms of glm helps to solve some methodological problems!
datalp = as.data.frame (read_xlsx("data.xlsx", 9))
str (datalp)

# let's start with a lm
datalp$FGP = (datalp$Total/datalp$seeds)*100

m2a = lm (FGP ~ as.factor (temp), data=datalp)
summary (m2a)

plot (m2a) # the diagnostic plots look fine, but we have only two observations per temperature...

# Because of the low number of replicates, we transform data to binary variables
# kudos to Lukas Heiland

n <- nrow(datalp)
dat3 <- datalp[rep(seq_len(n), times = 2), ]
dat3$germinated <- rep(c(1, 0), each = n)

repetitions1 <- datalp$Total
repetitions0 <- datalp$seeds - datalp$Total
repetitions <- c(repetitions1, repetitions0)

datalpbinary  = dat3[rep(seq_len(2*n), times = repetitions), ]

# binomial glm
datalpbinary$temp = as.factor(datalpbinary$temp)

m2b = glm (germinated ~ temp, family='binomial', data=datalpbinary)
summary (m2b)

x11 ()
simres3 = simulateResiduals(m2b)
plot (simres3)

library (emmeans)
postm1 = lsmeans (m2b,
                  pairwise ~ temp,
                  adjust = "Tukey") #Tukey-adjusted comparisons 
postm1


# understanding the output
# the estimates are logits - units or effect sizes that are hard to understand
plot (allEffects(m2b))

# converting logits to probabilities ('percentage' in this case)
exp(-1.07)/(1+exp(-1.07))

# automatic calculation:
# taken from https://sebastiansauer.github.io/convert_logit2prob/

logit2prob <- function(logit){
  odds <- exp(logit)
  prob <- odds / (1 + odds)
  return(prob)
}
logit2prob(coef(m2b))