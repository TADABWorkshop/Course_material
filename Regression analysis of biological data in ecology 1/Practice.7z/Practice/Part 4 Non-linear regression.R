# TADAP workshop, Uni Pisa, 2023

# Part 4. Non-linear regression
# Seedling frost-resistance in Antoxanthum alpinum

library (readxl)
frost = read_xlsx('Data.xlsx', 6)

# check the data structure
summary (frost)
str (frost)

# plot the data 
x11 ()
par(mfrow=c(1,2)) # Plot graphs in 1 row, 2 columns 

plot (frost$SR ~ frost$Temp)
plot (frost$SR ~ abs(frost$Temp))

library (ggplot2)
ggplot (aes(x=abs(Temp), y=SR), dat=frost)+
  geom_point ()+
  geom_smooth(method="lm", color="blue")+ # linear model
  geom_smooth(method="loess", color="red")+ # non-linear model
  theme_bw ()

#let's start with a simple glm
m1 = lm (SR ~ abs(Temp), data=frost)
summary (m1)

x11 ()
plot (m1) # Actually, a 'simple' linear model might be used here to quantify  
          # the seedling survival and temperature


# However, there are many cases, when non-linear functions/regressions is the only solution
frost2 = read_xlsx('Data.xlsx', 10)

x11 ()
ggplot (aes(x=abs(Temp), y=SR), dat=frost2)+
  geom_point ()+
  geom_smooth(method="lm", color="blue")+ # linear model
  geom_smooth(method="loess", color="red")+ # non-linear model
  theme_bw ()

m2 = lm (SR ~ abs(Temp), data=frost2)
summary (m2)

par(mfrow=c(2,2))
plot (m2)

library (drc) # dose-response curve
frost.m1 = drm (SR ~ abs(Temp), 
                data=frost,
                fct = LL.4 # log-logistic model with 4 parameters. The most common type for such kind of data
                (names = c("Slope", "Lower Limit", "Upper Limit", "LT50"))) # name the model parameters

summary(frost.m1)

# plot the fitted model
x11 ()
par(mfrow=c(1,2))
plot (frost.m1, broken=TRUE, bty = "l")
plot (frost.m1, broken=TRUE, bty = "l", type="all")


# Model accuracy
# 1) Take a look at the graph - the regression line should fit the data
# ok

# 2) Formal test
modelFit(frost.m1)
# p-values >0.05 indicate a good model fit

# 3) Assumptions
# (1) Correct model 
# The model fits to the data

# (2) Variance homogeneity - the variance does not change along the line, i.e. there should not be a patterns
# (3) Normally of residuals - the points in the Q-Q plot should be along the line

x11 ()
par(mfrow=c(1,2))

# Variance homogeneity 
plot(residuals(frost.m1) ~ fitted(frost.m1), main="Residuals vs Fitted")
abline(h=0)

# Normally of residuals
qqnorm(residuals(frost.m1))
qqline(residuals(frost.m1))

# (4) Mutually independent measurement error - all the samples should be treated in the same way
# ok

# what about other models?
frost.m1 = drm (SR ~ abs(Temp), data=frost, fct = LL.4()) # log-logistic model with 4 parameters
frost.m2 = drm (SR ~ abs(Temp), data=frost, fct = W1.4()) # Weibull-I
frost.m3 = drm (SR ~ abs(Temp), data=frost, fct = W2.4()) # Weibull - II

x11 ()
plot(frost.m1, broken=TRUE, lwd=2, bty="l")
plot(frost.m2, add=TRUE, broken=TRUE, lty=2, lwd=2)
plot(frost.m3, add=TRUE, broken=TRUE, lty=3, lwd=2)

# Important: since the Weibull models are asymmetrical, the inflection point should be calculated 
ED(frost.m1,50,interval="delta")
ED(frost.m2,50,interval="delta")
ED(frost.m3,50,interval="delta")

# Are the EDs different among the models?
edLL= data.frame(ED(frost.m1,c(10,50,90),interval="delta", display=FALSE),ll="Log-logistic")            
edW1 = data.frame(ED(frost.m2,c(10,50,90),interval="delta", display=FALSE),ll="Weibull 1")
edW2 = data.frame(ED(frost.m3,c(10,50,90),interval="delta", display=FALSE),ll="Weibull 2")
CombED = rbind(edLL,edW1,edW2)

# more on drc: http://rstats4ag.org/dose-response-curves.html